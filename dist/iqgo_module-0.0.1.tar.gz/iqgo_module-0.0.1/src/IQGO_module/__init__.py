import IQGO_module


def main():
    print("Running IQGO_module")

if __name__ == "__main__":
    main()
import IQGO_module.iqgo_training


def main():
    print("Running IQGO_module")

if __name__ == "__main__":
    main()